import React from 'react';

const NewIdea = props => (
    <img src={props.idea.image} alt={props.idea.name} />
)

export default NewIdea;
